-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2024 at 06:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lets__read`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `payment_method` (IN `pm` VARCHAR(50))   BEGIN
    SELECT *
    FROM Payments 
    WHERE PaymentMethod = pm; 
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `UserID`, `Name`, `Email`, `Address`, `PhoneNumber`, `CreatedAt`) VALUES
(6, 6, 'Sakib Khan', 'sakib@gmail.com', 'Khulna', '678-901-2345', '2024-01-06 09:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `AuthorID` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Biography` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`AuthorID`, `Name`, `Biography`) VALUES
(1, 'Kazi Nazrul Islam', 'National Poet of Bangladesh'),
(2, 'Rabindranath Tagore', 'Bengali Famous Writer'),
(3, 'Jashim Uddin', 'Polli Kobi'),
(4, 'Humayon Ahmed', 'Drama and Film Maker'),
(5, 'Jibonanondo Das', 'Schoolteacher and magazine Publisher');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `BookID` bigint(20) UNSIGNED NOT NULL,
  `Title` varchar(255) NOT NULL,
  `AuthorID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `PublisherID` int(11) DEFAULT NULL,
  `ISBN` varchar(20) DEFAULT NULL,
  `PublicationYear` int(11) DEFAULT NULL,
  `Price` decimal(10,2) NOT NULL,
  `StockQuantity` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`BookID`, `Title`, `AuthorID`, `CategoryID`, `PublisherID`, `ISBN`, `PublicationYear`, `Price`, `StockQuantity`) VALUES
(1, 'Feluda Shomogro', 1, 1, 1, '1234567890123', 2020, 350.00, 5),
(2, 'Shei Shomoy', 2, 2, 2, '2345678901234', 2021, 250.00, 2),
(3, 'Chader Pahar', 3, 3, 3, '3456789012345', 2022, 125.00, 9),
(4, 'Dipu Number Two', 4, 4, 4, '4567890123456', 2023, 290.00, 11),
(5, 'Hazar Bochor Dhore', 5, 5, 5, '5678901234567', 2024, 200.00, 13),
(6, 'Deshe Bideshe', 6, 6, 6, '6789012345678', 2025, 170.00, 18),
(7, 'Ami Topu', 7, 7, 7, '7890123456789', 2026, 350.00, 7),
(8, 'Podda Nodir Majhi', 8, 8, 8, '8901234567890', 2027, 190.00, 12),
(9, 'Durbin', 9, 9, 9, '9012345678901', 2028, 210.00, 21),
(10, 'Putul Nacher Itikotha', 10, 10, 10, '0123456789012', 2029, 250.00, 11);

-- --------------------------------------------------------

--
-- Table structure for table `buyers`
--

CREATE TABLE `buyers` (
  `BuyerID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buyers`
--

INSERT INTO `buyers` (`BuyerID`, `UserID`, `Name`, `Email`, `Address`, `PhoneNumber`, `CreatedAt`) VALUES
(1, 1, 'Nur Muhammad', 'nur@gmail.com', 'Tangail', '123-456-7890', '2024-01-01 04:00:00'),
(2, 2, 'Fahim Ferdous', 'fahim@gmail.com', 'Pabna', '234-567-8901', '2024-01-02 05:00:00'),
(4, 4, 'Tanvir Mahmud', 'tanvir@gmail.com', 'Mymansingh', '456-789-0123', '2024-01-04 07:00:00'),
(5, 5, 'Azra Zerin', 'azra@gmail.com', 'Natore', '567-890-1234', '2024-01-05 08:00:00'),
(7, 7, 'Halim Madbor', 'halim@gmail.com', 'Bogra', '789-012-3456', '2024-01-07 10:00:00'),
(8, 8, 'Hannah Ali', 'hannah@gmail.com', 'Sylhet', '890-123-4567', '2024-01-08 11:00:00'),
(10, 10, 'Amir Khan', 'amir@gmail.com', 'Rajshahi', '012-345-6789', '2024-01-10 13:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `CategoryID` bigint(20) UNSIGNED NOT NULL,
  `CategoryName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CategoryID`, `CategoryName`) VALUES
(3, 'Adult 18+'),
(5, 'Classic'),
(6, 'Documentary'),
(7, 'Experimental'),
(2, 'Ghost Story'),
(4, 'Science Friction'),
(1, 'Thriller');

-- --------------------------------------------------------

--
-- Stand-in structure for view `filteredbooks`
-- (See below for the actual view)
--
CREATE TABLE `filteredbooks` (
`BookID` bigint(20) unsigned
,`Title` varchar(255)
,`AuthorID` int(11)
,`CategoryID` int(11)
,`PublisherID` int(11)
,`ISBN` varchar(20)
,`PublicationYear` int(11)
,`Price` decimal(10,2)
,`StockQuantity` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `loyaltypointshistory`
--

CREATE TABLE `loyaltypointshistory` (
  `PointID` bigint(20) UNSIGNED NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `PointsEarned` int(11) DEFAULT NULL,
  `TransactionDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loyaltypointshistory`
--

INSERT INTO `loyaltypointshistory` (`PointID`, `UserID`, `PointsEarned`, `TransactionDate`) VALUES
(1, 2, 400, '2024-01-06 09:00:00'),
(2, 5, 700, '2024-01-07 10:00:00'),
(3, 8, 300, '2024-01-08 11:00:00'),
(4, 7, 600, '2024-01-09 12:00:00'),
(5, 4, 200, '2024-01-10 13:00:00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `maxcreditcardpayment`
-- (See below for the actual view)
--
CREATE TABLE `maxcreditcardpayment` (
`MaxPayment` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `OrderDetailID` bigint(20) UNSIGNED NOT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `BookID` int(11) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `UnitPrice` decimal(10,2) DEFAULT NULL,
  `TotalPrice` decimal(10,2) GENERATED ALWAYS AS (`Quantity` * `UnitPrice`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`OrderDetailID`, `OrderID`, `BookID`, `Quantity`, `UnitPrice`) VALUES
(1, 1, 1, 1, 80.00),
(2, 2, 7, 3, 90.00),
(3, 3, 1, 1, 50.00),
(4, 4, 9, 2, 125.00),
(5, 5, 7, 4, 110.00),
(6, 6, 2, 3, 70.00),
(7, 7, 3, 5, 190.00);

-- --------------------------------------------------------

--
-- Stand-in structure for view `orderdetailsview`
-- (See below for the actual view)
--
CREATE TABLE `orderdetailsview` (
`OrderID` bigint(20) unsigned
,`UserID` int(11)
,`OrderDate` timestamp
,`TotalAmount` decimal(10,2)
,`ShippingAddress` varchar(255)
,`OrderStatus` enum('Pending','Shipped','Delivered','Cancelled')
,`BookID` int(11)
,`Quantity` int(11)
,`UnitPrice` decimal(10,2)
,`LineTotal` decimal(20,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` bigint(20) UNSIGNED NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `OrderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `TotalAmount` decimal(10,2) DEFAULT NULL,
  `ShippingAddress` varchar(255) DEFAULT NULL,
  `OrderStatus` enum('Pending','Shipped','Delivered','Cancelled') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `UserID`, `OrderDate`, `TotalAmount`, `ShippingAddress`, `OrderStatus`) VALUES
(1, 1, '2024-01-01 04:00:00', 500.00, 'Tangail', 'Pending'),
(2, 2, '2024-01-02 05:00:00', 450.00, 'Mirzapur', 'Shipped'),
(3, 4, '2024-01-04 07:00:00', 370.00, 'Dhaka', 'Cancelled'),
(4, 5, '2024-01-05 08:00:00', 270.00, 'Mirpur', 'Pending'),
(5, 7, '2024-01-07 10:00:00', 480.00, 'Dhanmondi', 'Delivered'),
(6, 8, '2024-01-08 11:00:00', 510.00, 'Sylhet', 'Cancelled'),
(7, 10, '2024-01-10 13:00:00', 290.00, 'Pabna', 'Shipped');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` bigint(20) UNSIGNED NOT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `PaymentMethod` enum('Credit Card','PayPal','Bank Transfer') NOT NULL,
  `PaymentDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `AmountPaid` decimal(10,2) DEFAULT NULL,
  `PaymentStatus` enum('Pending','Completed','Failed') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `OrderID`, `PaymentMethod`, `PaymentDate`, `AmountPaid`, `PaymentStatus`) VALUES
(1, 1, 'Credit Card', '2024-01-01 04:00:00', 500.00, 'Completed'),
(2, 2, 'PayPal', '2024-01-02 05:00:00', 450.00, 'Completed'),
(3, 3, 'Bank Transfer', '2024-01-03 06:00:00', 370.00, 'Completed'),
(4, 4, 'Credit Card', '2024-01-04 07:00:00', 270.00, 'Failed'),
(5, 5, 'PayPal', '2024-01-05 08:00:00', 480.00, 'Pending'),
(6, 6, 'Bank Transfer', '2024-01-06 09:00:00', 510.00, 'Completed'),
(7, 7, 'Credit Card', '2024-01-07 10:00:00', 290.00, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `promotions`
--

CREATE TABLE `promotions` (
  `PromotionID` bigint(20) UNSIGNED NOT NULL,
  `BookID` int(11) DEFAULT NULL,
  `DiscountPercentage` int(11) DEFAULT NULL CHECK (`DiscountPercentage` between 0 and 100),
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `promotions`
--

INSERT INTO `promotions` (`PromotionID`, `BookID`, `DiscountPercentage`, `StartDate`, `EndDate`) VALUES
(1, 1, 10, '2024-01-01', '2024-01-31'),
(2, 3, 30, '2024-02-01', '2024-02-28'),
(3, 4, 20, '2024-03-01', '2024-03-31'),
(4, 7, 15, '0024-04-01', '2024-04-30'),
(5, 10, 25, '2024-05-01', '2024-05-31');

-- --------------------------------------------------------

--
-- Table structure for table `publishers`
--

CREATE TABLE `publishers` (
  `PublisherID` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `ContactInfo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `publishers`
--

INSERT INTO `publishers` (`PublisherID`, `Name`, `Address`, `ContactInfo`) VALUES
(1, 'Mayurpankhi', 'Dhanmondi', 'mayur@gmail.com'),
(2, 'Guba Books', 'Mirpur', 'guba@gmail.com'),
(3, 'Somoy', 'Uttora', 'somoy@gmail.com'),
(4, 'Chandramukhi', 'Jassore', 'chandra@gmail.com'),
(5, 'Niladri', 'Bashundhara', 'niladri@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `ReviewID` bigint(20) UNSIGNED NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `BookID` int(11) DEFAULT NULL,
  `Rating` int(11) DEFAULT NULL CHECK (`Rating` between 1 and 5),
  `ReviewText` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`ReviewID`, `UserID`, `BookID`, `Rating`, `ReviewText`) VALUES
(1, 5, 3, 4, 'Excellent book!'),
(2, 7, 5, 3, 'Very good read!');

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `SellerID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`SellerID`, `UserID`, `Name`, `Email`, `Address`, `PhoneNumber`, `CreatedAt`) VALUES
(3, 3, 'Samanta Islam', 'samanta@gmail.com', 'Ashulia', '345-678-9012', '2024-01-03 06:00:00'),
(9, 9, 'Iman Ali', 'iman@gmail.com', 'Dhaka', '901-234-5678', '2024-01-09 12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` text NOT NULL,
  `Role` enum('Buyer','Seller','Admin') DEFAULT 'Buyer',
  `Address` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Name`, `Email`, `Password`, `Role`, `Address`, `PhoneNumber`, `CreatedAt`) VALUES
(1, 'Nur Muhammad', 'nur@gmail.com', 'password1', 'Buyer', 'Tangail', '123-456-7890', '2024-01-01 04:00:00'),
(2, 'Fahim Ferdous', 'fahim@gmail.com', 'password2', 'Buyer', 'Pabna', '234-567-8901', '2024-01-02 05:00:00'),
(3, 'Samanta Islam', 'samanta@gmail.com', 'password3', 'Seller', 'Ashulia', '345-678-9012', '2024-01-03 06:00:00'),
(4, 'Tanvir Mahmud', 'tanvir@gmail.com', 'password4', 'Buyer', 'Mymansingh', '456-789-0123', '2024-01-04 07:00:00'),
(5, 'Azra Zerin', 'azra@gmail.com', 'password5', 'Buyer', 'Natore', '567-890-1234', '2024-01-05 08:00:00'),
(6, 'Sakib Khan', 'sakib@gmail.com', 'password6', 'Admin', 'Khulna', '678-901-2345', '2024-01-06 09:00:00'),
(7, 'Halim Madbor', 'halim@gmail.com', 'password7', 'Buyer', 'Bogra', '789-012-3456', '2024-01-07 10:00:00'),
(8, 'Hannah Ali', 'hannah@gmail.com', 'password8', 'Buyer', 'Sylhet', '890-123-4567', '2024-01-08 11:00:00'),
(9, 'Iman Ali', 'iman@gmail.com', 'password9', 'Seller', 'Dhaka', '901-234-5678', '2024-01-09 12:00:00'),
(10, 'Amir Khan', 'amir@gmail.com', 'password10', 'Buyer', 'Rajshahi', '012-345-6789', '2024-01-10 13:00:00');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `after_user_insert` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    IF NEW.Role = 'Buyer' THEN
        INSERT INTO Buyers (BuyerID, UserID, Name, Email, Address, PhoneNumber, CreatedAt)
        VALUES (NEW.UserID, NEW.UserID, NEW.Name, NEW.Email, NEW.Address, NEW.PhoneNumber, NEW.CreatedAt);
    ELSEIF NEW.Role = 'Seller' THEN
        INSERT INTO Sellers (SellerID, UserID, Name, Email, Address, PhoneNumber, CreatedAt)
        VALUES (NEW.UserID, NEW.UserID, NEW.Name, NEW.Email, NEW.Address, NEW.PhoneNumber, NEW.CreatedAt);
    ELSEIF NEW.Role = 'Admin' THEN
        INSERT INTO Admins (AdminID, UserID, Name, Email, Address, PhoneNumber, CreatedAt)
        VALUES (NEW.UserID, NEW.UserID, NEW.Name, NEW.Email, NEW.Address, NEW.PhoneNumber, NEW.CreatedAt);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewbookswithstock`
-- (See below for the actual view)
--
CREATE TABLE `viewbookswithstock` (
`CategoryID` int(11)
,`TotalBooks` bigint(21)
,`TotalStock` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vieworderdetails`
-- (See below for the actual view)
--
CREATE TABLE `vieworderdetails` (
`OrderDetailID` bigint(20) unsigned
,`OrderID` int(11)
,`BookID` int(11)
,`Quantity` int(11)
,`UnitPrice` decimal(10,2)
,`CalculatedTotalPrice` decimal(20,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `WishlistID` bigint(20) UNSIGNED NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `BookID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`WishlistID`, `UserID`, `BookID`) VALUES
(1, 1, 3),
(2, 4, 6),
(3, 5, 5);

-- --------------------------------------------------------

--
-- Structure for view `filteredbooks`
--
DROP TABLE IF EXISTS `filteredbooks`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `filteredbooks`  AS SELECT `books`.`BookID` AS `BookID`, `books`.`Title` AS `Title`, `books`.`AuthorID` AS `AuthorID`, `books`.`CategoryID` AS `CategoryID`, `books`.`PublisherID` AS `PublisherID`, `books`.`ISBN` AS `ISBN`, `books`.`PublicationYear` AS `PublicationYear`, `books`.`Price` AS `Price`, `books`.`StockQuantity` AS `StockQuantity` FROM `books` WHERE `books`.`BookID` in (select `books`.`BookID` from `books` where `books`.`Price` >= 200 AND `books`.`BookID` > 5) ;

-- --------------------------------------------------------

--
-- Structure for view `maxcreditcardpayment`
--
DROP TABLE IF EXISTS `maxcreditcardpayment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `maxcreditcardpayment`  AS SELECT max(`payments`.`AmountPaid`) AS `MaxPayment` FROM `payments` WHERE `payments`.`PaymentMethod` = 'Credit Card' ;

-- --------------------------------------------------------

--
-- Structure for view `orderdetailsview`
--
DROP TABLE IF EXISTS `orderdetailsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `orderdetailsview`  AS SELECT `orders`.`OrderID` AS `OrderID`, `orders`.`UserID` AS `UserID`, `orders`.`OrderDate` AS `OrderDate`, `orders`.`TotalAmount` AS `TotalAmount`, `orders`.`ShippingAddress` AS `ShippingAddress`, `orders`.`OrderStatus` AS `OrderStatus`, `orderdetails`.`BookID` AS `BookID`, `orderdetails`.`Quantity` AS `Quantity`, `orderdetails`.`UnitPrice` AS `UnitPrice`, `orderdetails`.`Quantity`* `orderdetails`.`UnitPrice` AS `LineTotal` FROM (`orders` join `orderdetails` on(`orders`.`OrderID` = `orderdetails`.`OrderID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `viewbookswithstock`
--
DROP TABLE IF EXISTS `viewbookswithstock`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewbookswithstock`  AS SELECT `books`.`CategoryID` AS `CategoryID`, count(`books`.`BookID`) AS `TotalBooks`, sum(`books`.`StockQuantity`) AS `TotalStock` FROM `books` GROUP BY `books`.`CategoryID` HAVING sum(`books`.`StockQuantity`) > 10 ;

-- --------------------------------------------------------

--
-- Structure for view `vieworderdetails`
--
DROP TABLE IF EXISTS `vieworderdetails`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vieworderdetails`  AS SELECT `orderdetails`.`OrderDetailID` AS `OrderDetailID`, `orderdetails`.`OrderID` AS `OrderID`, `orderdetails`.`BookID` AS `BookID`, `orderdetails`.`Quantity` AS `Quantity`, `orderdetails`.`UnitPrice` AS `UnitPrice`, `orderdetails`.`Quantity`* `orderdetails`.`UnitPrice` AS `CalculatedTotalPrice` FROM `orderdetails` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`AuthorID`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`BookID`),
  ADD UNIQUE KEY `ISBN` (`ISBN`);

--
-- Indexes for table `buyers`
--
ALTER TABLE `buyers`
  ADD PRIMARY KEY (`BuyerID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CategoryID`),
  ADD UNIQUE KEY `CategoryName` (`CategoryName`);

--
-- Indexes for table `loyaltypointshistory`
--
ALTER TABLE `loyaltypointshistory`
  ADD PRIMARY KEY (`PointID`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`OrderDetailID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`);

--
-- Indexes for table `promotions`
--
ALTER TABLE `promotions`
  ADD PRIMARY KEY (`PromotionID`);

--
-- Indexes for table `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`PublisherID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ReviewID`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`SellerID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`WishlistID`),
  ADD UNIQUE KEY `UserID` (`UserID`,`BookID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `AuthorID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `BookID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `CategoryID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `loyaltypointshistory`
--
ALTER TABLE `loyaltypointshistory`
  MODIFY `PointID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `OrderDetailID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `PaymentID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `promotions`
--
ALTER TABLE `promotions`
  MODIFY `PromotionID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `publishers`
--
ALTER TABLE `publishers`
  MODIFY `PublisherID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `ReviewID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `WishlistID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
